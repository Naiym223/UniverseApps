/** ARRAY OF USERS WHO WILL HAVE ADMIN BASED ACCESS
 * 
 * HEADS ARE ALSO SOLELY RESPONSIBLE FOR DEV APPS
 * 
 * example: 
 * 
 * exports.heads = [
 *   '510065483693817867',
 *   '510065483693817867'
 * ]
*/
exports.heads = [
  ''
];

/** ARRAY OF USERS WHO WILL HAVE PERMS TO APPROVE AND DENY APPS 
 * 
 * example: 
 * 
 * exports.managers = [
 *   '510065483693817867',
 *   '510065483693817867'
 * ]
*/
exports.managers = [
  ''
];

/** ARRAY OF USERS WHO WILL HAVE PERMS TO VIEW APPS
 * 
 * example: 
 * 
 * exports.mods = [
 *   '510065483693817867',
 *   '510065483693817867'
 * ]
*/
exports.mods = [
  ''
];
