<h2 align='center'>
  <img src="https://media.discordapp.net/attachments/653733403841134600/903307233096523796/IMG_0962.png" height='100px' width='100px' />
  <br> 
  Infinity Applications</h2>
<p align="center">
  Official Application/Recruitment Site for the Infinity Bot List Staff Team .
</p>

<hr>

<h2 align='center'>Self Hosting </h2>
<br>
<p align="center">
  • Download a Copy of the Code
  <br>
  • Extract to a Destination of choice!
  <br>
  • Run `npm install` and wait!
  <br>
  • Start the Code with <code>npm start</code>
  <br><br>
  * You will need to be whitelisted in our DB
</p>

<hr />

<h2>Copyright Notice</h2>
<p align="center">
 - You are not allowed to Host or Copy the code from this website for any purpose other then updating the website.
</p>

<br><br>

<a href="//www.dmca.com/Protection/Status.aspx?ID=6bfe1403-c4b3-45a4-921f-1359a6215327" style="display:none;" title="DMCA.com Protection Status" class="dmca-badge"><img src ="https://images.dmca.com/Badges/dmca-badge-w250-5x1-08.png?ID=6bfe1403-c4b3-45a4-921f-1359a6215327"  alt="DMCA.com Protection Status" /></a>

